<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Title -->
    <title>MMC</title>
 
    <!-- Linking of icons -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

    <!-- Path file of CSS -->
	<link rel="stylesheet" href="../CSS/Sidebar.css">

    <!-- Icon by page -->
    <link rel="icon" type="image/png" href="../Images/LogoMMC.png">
</head>
<body>
    
    <!-- Sidebar -->
    <aside class="Sidebar"> 
        <div class="logo">
            <img src="../Images/LogoMMC.png" alt="Logo of MMC">     
            <h2>MMC</h2>
        </div>

        <ul class="folio"> <!-- Links --> 
            <h3>Main Menu</h3>
            <li class="dash">
                <span class="material-symbols-outlined">bar_chart_4_bars</span> 
                <a href="#">Dashboard</a>
            </li>

            <li class="donate">
                <span class="material-symbols-outlined">diversity_3</span> 
                <a href="#">Donate</a>
            </li>

            <h3>Services</h3>
            <li class="trans">
                <span class="material-symbols-outlined">receipt_long</span> 
                <a href="#">Transactions</a>
            </li>

            <h3>My Account</h3>
            <li class="acc">
                <span class="material-symbols-outlined">account_circle</span> 
                <a href="#">Accounts</a>
            </li>

            <li class="set">
                <span class="material-symbols-outlined">toggle_on</span> 
                <a href="#">Settings</a>
            </li>
            
            <li class="btnLog">
                <span class="material-symbols-outlined">logout</span> 
                <a href="#">Logout</a>
            </li>
        </ul>
    </aside>

</body>
</html>
